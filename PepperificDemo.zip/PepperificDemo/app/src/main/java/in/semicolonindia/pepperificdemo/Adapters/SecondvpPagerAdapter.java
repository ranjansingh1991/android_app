package in.semicolonindia.pepperificdemo.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import in.semicolonindia.pepperificdemo.Fragment_Banner;

/**
 * Created by RANJAN SINGH on 9/25/2018.
 */

@SuppressWarnings("ALL")
public class SecondvpPagerAdapter extends FragmentStatePagerAdapter {



    public SecondvpPagerAdapter(FragmentManager fm) {
        super(fm);

    }


    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                Fragment_Banner tab1 = new Fragment_Banner();
                return tab1;

            case 1:
                Fragment_Banner tab6 = new Fragment_Banner();
                return tab6;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
}