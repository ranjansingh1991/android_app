package in.semicolonindia.gopreui_ex_2;

/**
 * Created by RANJAN SINGH on 10/5/2018.
 */

public class CircularImageView {
}
