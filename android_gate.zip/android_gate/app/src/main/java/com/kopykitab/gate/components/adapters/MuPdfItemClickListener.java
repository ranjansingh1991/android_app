package com.kopykitab.gate.components.adapters;

import com.kopykitab.gate.Book;


public interface MuPdfItemClickListener {
    void itemClicked(Book book);
}
