package in.semicolonindia.taskusingmap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

@SuppressWarnings("ALL")
public class ListViewAdapter extends ArrayAdapter<Model> {

    //the hero list that will be displayed
    private List<Model> heroList;

    //the context object
    private Context mCtx;

    //here we are getting the herolist and context
    //so while creating the object of this adapter class we need to give herolist and context
    public ListViewAdapter(List<Model> heroList, Context mCtx) {
        super(mCtx, R.layout.row, heroList);
        this.heroList = heroList;
        this.mCtx = mCtx;
    }

    //this method will return the list item
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //getting the layoutinflater
        LayoutInflater inflater = LayoutInflater.from(mCtx);

        //creating a view with our xml layout
        View listViewItem = inflater.inflate(R.layout.row, null, true);

        //getting text views
        TextView textViewName = listViewItem.findViewById(R.id.tvData);


        //Getting the hero for the specified position
        Model model = heroList.get(position);

        //setting hero values to textviews
        textViewName.setText(model.getName());
        //returning the listitem
        return listViewItem;
    }
}